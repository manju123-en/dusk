from django import  forms
from .models import EmpContact

class EmpContactForm(forms.ModelForm):
    class Meta:
        model = EmpContact
        fields = ['name', 'email', 'contact' , 'message']
        widgets = {
            'name': forms.TextInput(attrs={'class':'form-control'}  ) ,
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'contact' : forms.TextInput(attrs={'class': 'form-control'}),
            'message': forms.TextInput(attrs={'class': 'form-control'}),

        }