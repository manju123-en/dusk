from django.db import models

# Create your models here.

class Member(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=12)

    def __str__(self):
        return self.firstname + " " + self.lastname


class Employee(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=12)
    date = models.CharField(max_length=23)
    qual = models.CharField(max_length=23)
    datej = models.CharField(max_length=23)
    contact = models.IntegerField()
    gender = models.CharField(max_length=45)
    designation = models.CharField(max_length=45)
    dept = models.CharField(max_length=23)
    address = models.CharField(max_length=45)
    city = models.CharField(max_length=45)

    def __str__(self):
        return self.firstname + " " + self.lastname


class EmpContact(models.Model):
    name = models.CharField(max_length=34 ,error_messages={ 'required' :" enter valid name"})
    email = models.EmailField(max_length=45)
    contact = models.IntegerField()
    message= models.CharField(max_length=55 ,error_messages={ 'required' :" enter message approx 30 words"})

class CalculateSal(models.Model):
    name = models.CharField(max_length=20)
    date = models.CharField(max_length=20)
    month = models.CharField(max_length=23)
    sal = models.FloatField()
    med = models.FloatField()
    pf = models.FloatField()
    wd = models.IntegerField()
    hd = models.IntegerField()
    net = models.FloatField()


class DepartmentDetail(models.Model):
    dpid = models.IntegerField()
    dname  = models.CharField(max_length=33)
    dno = models.IntegerField()



class Leave(models.Model):
    ename = models.CharField(max_length=42)
    etype = models.CharField(max_length=42)
    sdate = models.CharField(max_length=42)
    edate = models.CharField(max_length=42)
    des = models.CharField(max_length=42)
    status = models.CharField(max_length=42)

