from django.shortcuts import render, redirect, HttpResponseRedirect
from .models import Member,EmpContact,CalculateSal,DepartmentDetail,Leave,Employee
from django.contrib import messages
from django.db.models import Q
# Create your views here.
from .forms import EmpContactForm
def index(request):
        return render(request, 'web/index.html')

def login(request):
    return render(request, 'web/login.html')

def about(request):
    return render(request, 'web/about.html')

def index(request):
    if request.method == 'POST':
        if Member.objects.filter(username=request.POST['username'], password=request.POST['password']).exists():
            member = Member.objects.get(username=request.POST['username'], password=request.POST['password'])
            return render(request, 'web/adminhome.html', {'member': member})
        else:
            context = {'msg': 'Invalid username or password'}
            return render(request, 'web/login.html', context)



def calculate(request):
    if request.method == "POST":
        name = request.POST['name']
        date = request.POST['date']
        month = request.POST['month']
        sal = request.POST['sal']
        med = request.POST['med']
        pf = request.POST['pf']
        wd = request.POST['wd']
        hd = request.POST['hd']
        net = request.POST['net']
        CalculateSal(name=name,date=date,month=month,sal=sal,med=med,pf=pf,wd=wd,hd=hd,net=net).save()
        return render(request,'web/calculatesal.html')

    else:
        return render(request,'Major_App/calculatesal.html')

def showsal(request):
    members = CalculateSal.objects.all()
    context = {'members': members}
    return render(request,'web/showsal.html',context)

def Sal(request,id):
    employee =CalculateSal.objects.get(id=id)
    employee.delete()
    return redirect("/show")

# def Serchsal(request):
#     if request.method == 'POST':
#         searched = request.POST['searched']
#         if searched:
#              match = Employee.objects.filter(username__icontains=searched)
#              if match:
#               return render(request,'web/employee.html',{'customers':match})
#              else:
#                messages.error(request,'no data found')
#         else:
#             return HttpResponseRedirect('/employee/')

#     return render(request, 'web/calculate_sal.html')

# def calculated_sal(request):
#     if request.method == "POST":
#         name = request.POST['name']
#         date = request.POST['date']
#         month = request.POST['month']
#         sal = request.POST['sal']
#         med = request.POST['med']
#         pf = request.POST['pf']
#         wd = request.POST['wd']
#         hd = request.POST['hd']
#         net = request.POST['net']
#         CalculateSal(name=name,date=date,month=month,sal=sal,med=med,pf=pf,wd=wd,hd=hd,net=net).save()
#         return render(request, 'web/employee.html')

#     else:
#         return render(request, 'web/employee.html')



def calculate_sal(request):
    if request.method == 'POST':
        searched = request.POST['searched']
        if searched:
             match = Employee.objects.filter(id__icontains=searched)
             if match:
              return render(request,'web/employee.html',{'customers':match})
             else:
               messages.error(request,'no data found')
        else:
            return HttpResponseRedirect('/employee/')

    return render(request, 'web/employee.html')
 

def cal(request):
    if request.method == "POST":
        name = request.POST['name']
        date = request.POST['date']
        month = request.POST['month']
        sal = request.POST['sal']
        med = request.POST['med']
        pf = request.POST['pf']
        wd = request.POST['wd']
        hd = request.POST['hd']
        net = request.POST['net']
        CalculateSal(name=name,date=date,month=month,sal=sal,med=med,pf=pf,wd=wd,hd=hd,net=net).save()
        return render(request, 'web/employee.html')

    else:
        return render(request, 'web/employee.html')


def adddept(request):
    if request.method =="POST":
        dpid  = request.POST['dpid']
        dname = request.POST['dname']
        dno = request.POST['dno']
        DepartmentDetail(dpid = dpid,dname=dname , dno = dno).save()
        return render(request,'web/adddept.html')

    else:
        return render(request,'web/adddept.html')


def deletedept(request):
    members = DepartmentDetail.objects.all()
    context = {'members': members}
    return render(request, 'web/deletedept.html', context)

def destroy(request,id):
    employee = DepartmentDetail.objects.get(id=id)
    employee.delete()
    return redirect("/delete dept")



def add_show(request):
    if request.method == 'POST':
        fm = EmpContactForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            cn = fm.cleaned_data['contact']
            msg = fm.cleaned_data['message']
            reg = EmpContact(name=nm, email=em, contact =cn , message= msg)
            reg.save()

            fm = EmpContactForm()
    else:
        fm = EmpContactForm()
    stud = EmpContact.objects.all()
    return render(request, 'web/contactfrom.html', {'form':fm, 'stu':stud})

def ShowContact(request):
    if request.method == 'POST':
        fm = EmpContactForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            cn = fm.cleaned_data['contact']
            ms = fm.cleaned_data['message']

            reg = EmpContact(name=nm ,email=em,contact=cn,message=ms)
            reg.save()

            fm = EmpContactForm()
    else:
        fm = EmpContactForm()
        stud = EmpContact.objects.all()
        return render(request, 'web/showcontact.html', {'form':fm, 'stu':stud})

def cont(request,id):
    employee =EmpContact.objects.get(id=id)
    employee.delete()
    return redirect("/showcontact")


def add_leave(request):
    if request.method =="POST":
        ename  = request.POST['ename']
        etype = request.POST['etype']
        sdate = request.POST['sdate']
        edate = request.POST['edate']
        des = request.POST['des']
        status = request.POST['status']
        Leave(ename=ename,etype=etype,sdate=sdate,edate=edate,des=des,status=status).save()
        return render(request, 'web/applyleave.html')
    else:
        return render(request,'web/applyleave.html')

def showleave(request):
    members = Leave.objects.all()
    context = {'members': members}
    return render(request,'web/showleaveinfo.html',context)


def leave(request,id):
    employee =Leave.objects.get(id=id)
    employee.delete()
    return redirect("/show leave")

def reg(request):
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            firstname = request.POST['firstname']
            lastname = request.POST['lastname']
            date = request.POST['date']
            qual = request.POST['qual']
            datej = request.POST['datej']
            contact = request.POST['contact']
            gender = request.POST['gender']
            designation = request.POST['designation']
            dept = request.POST['dept']
            address = request.POST['address']
            city = request.POST['city']
            member = Employee(username=username, password=password,
                            firstname=firstname ,lastname=lastname,date=date,qual=qual ,datej=datej,contact =contact,
                            gender=gender,designation=designation,dept=dept,address=address,city=city)
            member.save()
            messages.success(request, " New Employee " + request.POST['firstname']+ "   Regisered Sucesssfully...!")
            return render(request, 'web/empreg.html')

        else:
            return render(request, 'web/empreg.html')



def emplogin(request):
    return render(request, 'web/emplogin.html')

def home1(request):
    if request.method == 'POST':
        if Employee.objects.filter(username=request.POST['username'], password=request.POST['password']).exists():
            member = Employee.objects.get(username=request.POST['username'], password=request.POST['password'])
            return render(request, 'web/home1.html', {'member': member})
        else:
            context = {'msg': 'Invalid username or password'}
            return render(request, 'web/emplogin.html', context)


def deleteemp(request):
    members = Employee.objects.all()
    context = {'members': members}
    return render(request, 'web/deleteemp.html', context)


def Empdel(request,id):
    employee =Employee.objects.get(id=id)
    employee.delete()
    return redirect("/delete emp")


def homepage(request):
    return render(request, 'web/main.html')


def search(request):
    if request.method == "POST":
        srch = request.POST['srh']
        if srch:
            match = Employee.objects.filter(Q(firstname__icontains=srch) |
                                            Q(city__icontains=srch))
            if match:
                return render(request, 'web/search.html', {'sr': match})
            else:
                messages.error(request, "no result found")
        else:
            return HttpResponseRedirect('/search/')


    return render(request ,'web/search.html')


def salary(request):
    if request.method == "POST":
        srch = request.POST['srh']
        if srch:
            match = CalculateSal.objects.filter(Q(name__icontains=srch))

            if match:
                return render(request, 'web/sal.html', {'sr': match})
            else:
                messages.error(request, "no result found")
        else:
            return HttpResponseRedirect('/sal/')

    return render(request ,'web/sal.html')




def emp_sal(request):
    if request.method == "POST":
        srch = request.POST['srh']
        if srch:
            match = CalculateSal.objects.filter(Q(name__icontains=srch) |
                                                Q(month__icontains=srch))
            if match:
                return render(request, 'web/salary.html', {'sr': match})
            else:
                messages.error(request, "no result found")
        else:
            return HttpResponseRedirect('/sal/')

    return render(request,'web/salary.html')


def employee(request):
    if request.method == "POST":
        srch = request.POST['srh']
        if srch:
            match = CalculateSal.objects.filter(Q(name__icontains=srch) |
                                                Q(month__icontains=srch))
            if match:
                return render(request, 'web/emp.html', {'sr': match})
            else:
                messages.error(request, "no result found")
        else:
            return HttpResponseRedirect('/sal/')

    return render(request,'web/emp.html')


def edit(request, id):
    members = DepartmentDetail.objects.get(id=id)
    context = {'members': members}
    return render(request, 'web/edit.html', context)


def update(request, id):
    member = DepartmentDetail.objects.get(id=id)
    member.dpid = request.POST['dpid']
    member.dname = request.POST['dname']
    member.dno = request.POST['dno']
    member.save()
    return redirect('/delete dept')


def edit1(request, id):
    members = Leave.objects.get(id=id)
    context = {'members': members}
    return render(request, 'web/edit1.html', context)


def update1(request, id):
    member = Leave.objects.get(id=id)
    member.ename = request.POST['ename']
    member.etype = request.POST['etype']
    member.sdate = request.POST['sdate']
    member.edate = request.POST['edate']
    member.des = request.POST['des']
    member.status = request.POST['status']
    member.save()
    return redirect('/show leave')


def edit2(request, id):
    members = CalculateSal.objects.get(id=id)
    context = {'members': members}
    return render(request, 'web/edit2.html', context)


def update2(request, id):
    member = CalculateSal.objects.get(id=id)
    member.name = request.POST['name']
    member.date = request.POST['date']
    member.month = request.POST['month']
    member.sal = request.POST['sal']
    member.med = request.POST['med']
    member.pf = request.POST['pf']
    member.wd = request.POST['wd']
    member.hd = request.POST['hd']
    member.net = request.POST['net']
    member.save()
    return redirect('/show')

def edit3(request, id):
    members = Employee.objects.get(id=id)
    context = {'members': members}
    return render(request, 'web/edit3.html', context)



def update3(request, id):
    member = Employee.objects.get(id=id)
    member.username = request.POST['username']
    member.password = request.POST['password']
    member.firstname = request.POST['firstname']
    member.lastname = request.POST['lastname']
    member.date = request.POST['date']
    member.qual = request.POST['qual']
    member.datej = request.POST['datej']
    member.contact = request.POST['contact']
    member.gender = request.POST['gender']
    member.designation = request.POST['designation']
    member.dept = request.POST['dept']
    member.address = request.POST['address']
    member.city = request.POST['city']
    member.save()
    return redirect('/delete emp')

def status(request):

    if request.method == "POST":
        srch = request.POST['srh']
        if srch:
            match = Leave.objects.filter(Q(ename__icontains=srch) |
                                                Q(etype__icontains=srch))
            if match:
                return render(request, 'web/leave.html', {'sr': match})
            else:
                messages.error(request, "no result found")
        else:
            return HttpResponseRedirect('/status/')

    return render(request, 'web/leave.html')

